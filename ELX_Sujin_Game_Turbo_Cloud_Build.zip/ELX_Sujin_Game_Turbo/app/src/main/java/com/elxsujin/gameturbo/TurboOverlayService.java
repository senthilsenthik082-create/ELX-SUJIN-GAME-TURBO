package com.elxsujin.gameturbo;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;

public class TurboOverlayService extends Service {
    private WindowManager wm; private View panel; private TextView stats, advice; private BroadcastReceiver batteryReceiver;
    private int mode = 1; private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1),Color.rgb(65,91,100)); return d; }
    private TextView text(String s,int size,int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    private Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setPadding(dp(3),0,dp(3),0); b.setMinWidth(0); b.setBackground(shape(Color.rgb(34,57,66),12)); return b; }
    @Override public void onCreate() { super.onCreate(); startNotice(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showPanel(); registerBattery(); }
    private void startNotice() {
        String channel="elx_turbo";
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(channel,"Game Turbo panel",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); }
        Notification n=new Notification.Builder(this,channel).setContentTitle("ELX SUJIN GAME TURBO").setContentText("Floating game panel is active").setSmallIcon(android.R.drawable.ic_media_play).build();
        if(Build.VERSION.SDK_INT>=34) startForeground(7,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE); else startForeground(7,n);
    }
    private void showPanel() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(9),dp(8),dp(9),dp(8)); box.setBackground(shape(Color.rgb(14,25,31),18));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("ELX TURBO",12,Color.rgb(0,230,170)); title.setTypeface(null,Typeface.BOLD); top.addView(title,new LinearLayout.LayoutParams(0,dp(32),1));
        Button hide=btn("—"); top.addView(hide,new LinearLayout.LayoutParams(dp(40),dp(34))); box.addView(top);
        LinearLayout modes=new LinearLayout(this); modes.setOrientation(LinearLayout.HORIZONTAL);
        String[] names={"NORMAL","PERFORMANCE","MONSTER"};
        for(int k=0;k<3;k++){ final int selected=k; Button b=btn(names[k]); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1); p.setMargins(dp(2),dp(5),dp(2),dp(7)); modes.addView(b,p); b.setOnClickListener(v->{mode=selected; updateMode();}); }
        box.addView(modes);
        stats=text("Battery: --%   Temp: --°C",11,Color.WHITE); stats.setPadding(dp(2),dp(5),dp(2),dp(5)); box.addView(stats);
        advice=text("Balanced everyday play",11,Color.LTGRAY); advice.setPadding(dp(2),dp(5),dp(2),dp(7)); box.addView(advice);
        Button open=btn("OPEN FREE FIRE"); box.addView(open,new LinearLayout.LayoutParams(-1,dp(38)));
        Button close=btn("CLOSE PANEL"); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(34)); cp.topMargin=dp(5); box.addView(close,cp);
        hide.setOnClickListener(v->{ box.removeView(modes); box.removeView(stats); box.removeView(advice); box.removeView(open); box.removeView(close); hide.setText("+"); hide.setOnClickListener(w->{ box.addView(modes,1); box.addView(stats,2); box.addView(advice,3); box.addView(open,4); box.addView(close,5); hide.setText("—"); hide.setOnClickListener(z->{ box.removeView(modes); box.removeView(stats); box.removeView(advice); box.removeView(open); box.removeView(close); hide.setText("+"); hide.setOnClickListener(q->{ box.addView(modes,1); box.addView(stats,2); box.addView(advice,3); box.addView(open,4); box.addView(close,5); }); }); }); });
        open.setOnClickListener(v->{ Intent i=getPackageManager().getLaunchIntentForPackage("com.dts.freefireth"); if(i==null)i=getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax"); if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);} });
        close.setOnClickListener(v->stopSelf());
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(220),WindowManager.LayoutParams.WRAP_CONTENT,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; lp.x=dp(5); lp.y=0;
        box.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy; public boolean onTouch(View v, android.view.MotionEvent e){ if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;return false;} if(e.getAction()==2){lp.x=ox+(int)(sx-e.getRawX());lp.y=oy+(int)(e.getRawY()-sy); try{wm.updateViewLayout(box,lp);}catch(Exception ignored){} return true;} return false; }});
        panel=box; wm.addView(panel,lp); updateMode();
    }
    private void showPanelAgain(){ if(panel!=null){ stopSelf(); startService(new Intent(this,TurboOverlayService.class)); } }
    private void updateMode(){ if(advice==null)return; String s; if(mode==0)s="NORMAL: balanced play. Use comfortable graphics."; else if(mode==1)s="PERFORMANCE: choose Smooth graphics + High FPS if stable."; else s="MONSTER: prioritise FPS; lower graphics if phone heats up."; advice.setText(s); }
    private void registerBattery(){ batteryReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100),temp=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1); if(stats!=null){String t=temp<0?"--":String.format(java.util.Locale.US,"%.1f",temp/10f); stats.setText("Battery: "+(level<0?"--":(level*100/Math.max(1,scale))+"%")+"   Batt temp: "+t+"°C");}}}; registerReceiver(batteryReceiver,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); }
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){ if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){} panel=null;} if(batteryReceiver!=null){try{unregisterReceiver(batteryReceiver);}catch(Exception ignored){}} super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
