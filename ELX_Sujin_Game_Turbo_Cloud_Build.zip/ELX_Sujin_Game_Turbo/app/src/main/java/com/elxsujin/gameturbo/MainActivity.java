package com.elxsujin.gameturbo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(bg(Color.rgb(28,48,58), 14)); return b;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24)); root.setBackgroundColor(Color.rgb(16,24,32));
        TextView title = label("ELX SUJIN", 27, Color.WHITE); title.setTypeface(null, Typeface.BOLD);
        TextView sub = label("GAME TURBO  •  POCO C55 / 6GB RAM", 13, Color.rgb(0,214,160));
        TextView desc = label("Start the floating side panel, then open Free Fire. The panel stays above the game when Android allows overlays.", 15, Color.LTGRAY);
        desc.setPadding(0, dp(16), 0, dp(18));
        Button start = button("START FLOATING GAME PANEL");
        Button launch = button("OPEN FREE FIRE");
        Button stop = button("STOP FLOATING PANEL");
        TextView note = label("NORMAL  •  PERFORMANCE  •  MONSTER\n\nTemperature shows the phone battery sensor reading (not exact CPU temperature). Modes are game-setting profiles only: Android does not allow ordinary apps to force CPU/GPU overclocking or guarantee more headshots. Keep the phone cool and use a stable network.", 13, Color.rgb(190,204,210));
        note.setPadding(0, dp(20), 0, 0);
        root.addView(title); root.addView(sub); root.addView(desc);
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(56)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.topMargin = dp(12); root.addView(launch,p);
        p = new LinearLayout.LayoutParams(-1, dp(56)); p.topMargin = dp(12); root.addView(stop,p);
        root.addView(note);
        setContentView(root);

        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else startPanel();
        });
        launch.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
            if (i == null) i = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
            if (i != null) startActivity(i);
            else android.widget.Toast.makeText(this, "Free Fire / Free Fire MAX not found", android.widget.Toast.LENGTH_LONG).show();
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, TurboOverlayService.class)));
    }
    @Override protected void onResume() { super.onResume(); }
    private void startPanel() {
        Intent i = new Intent(this, TurboOverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        android.widget.Toast.makeText(this, "Floating panel started. Open Free Fire!", android.widget.Toast.LENGTH_SHORT).show();
    }
}
