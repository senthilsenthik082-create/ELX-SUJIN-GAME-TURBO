ELX SUJIN GAME TURBO - Android Studio project
Target device: POCO C55, 6GB RAM, 128GB storage, Android 14

IMPORTANT
- This is a real Android source project, not a ready-made APK yet.
- Open this folder in Android Studio and build: Build > Build Bundle(s) / APK(s) > Build APK(s).
- The generated APK will be in app/build/outputs/apk/debug/.
- Install it on your POCO C55.

FIRST USE
1. Open ELX SUJIN GAME TURBO.
2. Tap START FLOATING GAME PANEL.
3. Allow "Display over other apps" permission.
4. Return to the app, tap START FLOATING GAME PANEL again if needed.
5. Open Free Fire. Drag the floating panel to a comfortable side position.
6. Use NORMAL / PERFORMANCE / MONSTER. CLOSE PANEL stops the overlay.

WHAT IT CAN DO
- Floating panel over other apps (Android overlay permission required).
- NORMAL, PERFORMANCE and MONSTER game-setting guidance profiles.
- Battery percentage and battery-sensor temperature display.
- Launch Free Fire or Free Fire MAX.

LIMITATIONS
- Android apps without root/system privileges cannot force CPU/GPU overclocking, change Free Fire aim, guarantee headshots, or directly cool the phone.
- Temperature shown is battery sensor temperature, not a full CPU/GPU temperature reading.
- The mode buttons change recommendations shown in the panel; they do not unlock hidden hardware performance.
- Keep vents clear, avoid playing while charging, lower graphics if hot, and use a stable connection.
- Overlay permission and foreground notification are required. Some MIUI/HyperOS battery restrictions may stop the overlay; allow auto-start/background activity if the phone offers those settings.
